

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8">
            <h2>Produk</h2>
            <input type="text" id="search" class="form-control mb-4" placeholder="Cari produk...">
            <div id="product-list" class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 product-item">
                    <div class="card mb-4">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($product->name); ?></h5>
                            <p class="card-text">Harga: Rp. <?php echo e(number_format($product->price, 0, ',', '.')); ?></p>
                            <form action="<?php echo e(route('cashier.add_to_cart')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <button type="submit" class="btn btn-primary">Tambah ke Keranjang</button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="col-md-4">
            <h2>Keranjang</h2>
            <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
            <?php endif; ?>
            <div class="card mb-2 p-2">

                <table class="table table-bordered">
                    <tr>
                        <th>Nama</th>
                        <th>Kuantitas</th>
                        <th>Harga</th>
                        <th>Aksi</th>
                    </tr>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item['name']); ?></td>
                        <td><?php echo e($item['quantity']); ?></td>
                        <td>Rp. <?php echo e(number_format($item['price'], 0, ',', '.')); ?></td>
                        <td>
                            <form action="<?php echo e(route('cashier.remove_from_cart')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($id); ?>">
                                <button type="submit" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus item ini dari keranjang?')">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <h4>Total: Rp. <?php echo e(number_format($total, 0, ',', '.')); ?></h4>
                <?php if(count($cart) > 0): ?>
                <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#paymentModal">Checkout</button>
                <?php endif; ?>
            </div>

        </div>
    </div>
</div>

<!-- Payment Modal -->
<div class="modal fade" id="paymentModal" tabindex="-1" aria-labelledby="paymentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('cashier.checkout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title" id="paymentModalLabel">Pilih Metode Pembayaran</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="payment-method" class="form-label">Metode Pembayaran</label>
                        <select class="form-select" id="payment-method" name="payment_method" required>
                            <option value="cash" selected>Cash</option>
                            <option value="debit">Debit</option>
                            <option value="ewallet">E-Wallet</option>
                        </select>
                    </div>
                    <div class="mb-3" id="cash-payment">
                        <label for="cash-paid" class="form-label">Jumlah Uang Tunai</label>
                        <input type="number" class="form-control" id="cash-paid" name="cash_paid">
                    </div>
                    <div class="mb-3" id="change-due">
                        <label for="change-due" class="form-label">Kembalian</label>
                        <input type="text" class="form-control" id="change-due-input" readonly>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="submit" class="btn btn-primary">Checkout</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Default payment method is "cash"
        document.getElementById('payment-method').value = 'cash';
        document.getElementById('cash-payment').style.display = 'block';
        document.getElementById('change-due').style.display = 'block';

        const total = <?php echo e($total); ?>;
        const cashPaidInput = document.getElementById('cash-paid');
        const changeDueInput = document.getElementById('change-due-input');

        cashPaidInput.addEventListener('input', function() {
            const cashPaid = parseFloat(cashPaidInput.value);
            if (!isNaN(cashPaid)) {
                const changeDue = cashPaid - total;
                changeDueInput.value = 'Rp' + changeDue.toLocaleString('id-ID');
            }
        });

        document.getElementById('payment-method').addEventListener('change', function() {
            if (this.value === 'cash') {
                document.getElementById('cash-payment').style.display = 'block';
                document.getElementById('change-due').style.display = 'block';
                changeDueInput.style.display = 'block';
            } else {
                document.getElementById('cash-payment').style.display = 'none';
                document.getElementById('change-due').style.display = 'none';
                changeDueInput.style.display = 'none';
            }
        });
    });

    document.getElementById('search').addEventListener('input', function() {
        let query = this.value;

        fetch(`/cashier/search?query=${query}`)
            .then(response => response.json())
            .then(data => {
                let productList = document.getElementById('product-list');
                productList.innerHTML = '';

                data.forEach(product => {
                    productList.innerHTML += `
                        <div class="col-md-4 product-item">
                            <div class="card mb-4">
                                <div class="card-body">
                                    <h5 class="card-title">${product.name}</h5>
                                    <p class="card-text">Harga: Rp. ${Number(product.price).toLocaleString('id-ID')}</p>
                                    <form action="/cashier/add-to-cart" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="product_id" value="${product.id}">
                                        <button type="submit" class="btn btn-primary">Tambah ke Keranjang</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    `;
                });
            });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JC\bakery-cashier\resources\views/cashier/index.blade.php ENDPATH**/ ?>