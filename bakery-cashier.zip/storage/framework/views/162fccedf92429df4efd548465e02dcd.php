

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card mb-2 p-2">
        <h2>Detail Penjualan (ID: <?php echo e($sale->id); ?>)</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nama Produk</th>
                    <th>Kuantitas</th>
                    <th>Harga</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sale->itemPembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->product->name); ?></td>
                    <td><?php echo e($item->quantity); ?></td>
                    <td>Rp<?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                    <td>Rp<?php echo e(number_format($item->quantity * $item->price, 0, ',', '.')); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php if($sale->change_due != null): ?>
        <h6>kembalian: Rp<?php echo e(number_format($sale->change_due, 0, ',', '.')); ?></h6>
        <?php endif; ?>
        <h4>Total: Rp<?php echo e(number_format($sale->total, 0, ',', '.')); ?></h4>
        <br>
        <a href="<?php echo e(route('laporan.index')); ?>" class="btn btn-primary">Kembali ke Laporan Penjualan</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JC\bakery-cashier\resources\views/laporan/show.blade.php ENDPATH**/ ?>