

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h2 class="text-center">Struk Pembelian</h2>
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">Pembelian ID: <?php echo e($pembelian->id); ?></h5>
        </div>
        <div class="card-body">
            <p class="card-text"><strong>Tanggal:</strong> <?php echo e($pembelian->created_at->format('d-m-Y H:i:s')); ?></p>
            <p class="card-text"><strong>Metode Pembayaran:</strong> <?php echo e(ucfirst($pembelian->payment_method)); ?></p>
            <?php if($pembelian->payment_method === 'cash'): ?>
                <p class="card-text"><strong>Jumlah Tunai:</strong> Rp<?php echo e(number_format($pembelian->cash_paid, 0, ',', '.')); ?></p>
                <p class="card-text"><strong>Kembalian:</strong> Rp<?php echo e(number_format($pembelian->change_due, 0, ',', '.')); ?></p>
            <?php endif; ?>
            <h4 class="mt-4">Total: Rp<?php echo e(number_format($pembelian->total, 0, ',', '.')); ?></h4>

            <h5 class="mt-4">Detail Item:</h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Produk</th>
                        <th>Kuantitas</th>
                        <th>Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pembelian->itemPembelian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->product->name); ?></td>
                            <td><?php echo e($item->quantity); ?></td>
                            <td>Rp<?php echo e(number_format($item->price, 0, ',', '.')); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <div class="text-center mt-4">
                <a href="<?php echo e(route('laporan.index')); ?>" class="btn btn-primary">Kembali ke Laporan</a>
                <button onclick="window.print();" class="btn btn-secondary">Print</button>
            </div>
        </div>
    </div>
</div>

<style>
    @media print {
        body * {
            visibility: hidden;
        }
        .container, .container * {
            visibility: visible;
        }
        .container {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
        }
        .btn {
            display: none;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JC\bakery-cashier\resources\views/laporan/receipt.blade.php ENDPATH**/ ?>