

<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <div class="card mb-2 p-2">
        <h2>Laporan Penjualan</h2>
        <form action="<?php echo e(route('laporan.index')); ?>" method="GET" class="mb-3">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-3">
                    <label for="date" class="form-label">Tanggal</label>
                    <input type="date" id="date" name="date" class="form-control" value="<?php echo e(request('date', now()->toDateString())); ?>">
                </div>
                <div class="col-md-3">
                    <label for="month" class="form-label">Bulan</label>
                    <select id="month" name="month" class="form-select">
                        <?php $__currentLoopData = range(1, 12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($month); ?>" <?php echo e(request('month', now()->month) == $month ? 'selected' : ''); ?>>
                                <?php echo e(DateTime::createFromFormat('!m', $month)->format('F')); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="year" class="form-label">Tahun</label>
                    <select id="year" name="year" class="form-select">
                        <?php $__currentLoopData = range(2020, now()->year); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($year); ?>" <?php echo e(request('year', now()->year) == $year ? 'selected' : ''); ?>>
                                <?php echo e($year); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary">Filter</button>
                </div>
            </div>
        </form>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>ID-Pembelian</th>
                    <th>Total</th>
                    <th>Tanggal</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($sale->id); ?></td>
                    <td>Rp<?php echo e(number_format($sale->total, 0, ',', '.')); ?></td>
                    <td><?php echo e($sale->created_at); ?></td>
                    <td>
                        <a href="<?php echo e(route('laporan.show', $sale->id)); ?>" class="btn btn-info">Detail</a>
                        <a href="<?php echo e(route('laporan.receipt', $sale->id)); ?>" class="btn btn-secondary">Receipt</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JC\bakery-cashier\resources\views/laporan/index.blade.php ENDPATH**/ ?>